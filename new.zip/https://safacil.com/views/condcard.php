1<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>

<body>
<section class="content">
  <h2 style="color:goldenrod">Kondisyon Jeneral</h2>
  <p>
    <small style="font-style: italic">Dènye modifikasyon : 25 jen 2024</small>
    </br>  </br>  </br>
  </p>
  <p>
  <h3>1. Jeneral</h3>
 Kondisyon sa yo konstitiye kondisyon jiridik ant ou menm ak SAFACIL pou itilizasyon tout sèvis SAFACIL ofri yo.
  </p>

  <p>
 <h3>2. Kont SAFACIL ou an</h3>
  Kont SAFACIL ou genyen an pa yon bank, ou ka mete kòb sou kont SAFACIL ou an apati de plizyè lòt sèvis deyò OSWA SAFACIL PAY pou ka itilize sèvis SAFACIL ofri yo. SAFACIL rezève dwa pou bloke kont ou an si ou vyole kondisyon ki pral site anba yo.
    </p>

    <p>
 <h3>3. Itilizasyon Kont SAFACIL</h3>
  Aprè ou fin kreye yon kont sou SAFACIL ou pagen dwa pou pataje enfo koneksyon kont ou an ak pèsonn, pou evite pirataj, epi ou dwe aktive 2FA pou ka toujou resevwa yon kòd koneksyon pa SMS, Whatsapp oswa imel pou w ka gen aksè ak kont lan.
  <br>
  <br>
1 - Ou pa dwe kreye 2 kont ak menm pyès idantite a. ni ak menm nimewo oswa menm imel.
</br>
2 - Ou pa dwe itilize sèvis SWAP lan pou eseye jwenn enterè.(Ou ka pèdi kòb, kont ou ka menm rive bloke si ou ale nan litij)
</br>
3 - Si ou eseye pase KYC an plis ke 5 fwa kont ou an ka gen difikilte pou fè gwo tranzaksyon.
</br>
4 - Pa voye kòb bay moun ou pa konnen ni sou adrès ou pa konnen.
</br> 
5 - Toujou li sa ki ekri yo avan ou fè yon tranzaksyon.
<br>
6 - Respekte prensip kominote SAFACIL gen sou rezo sosyal yo.
    </p>

    <p>
 <h3>4. Depo ak Transfè</h3>
  Asire w ke ou byen ranpli fomilè yo lè ke w ap fè yon depo oswa transfè, SAFACIL pap responsab okenn erè ki sòti bò kote pa w. verifye depo minimòm ak transfè minimòm nan avan menm ke ou lanse tranzaksyon an. Si ou fè yon erè nan fomilè yo SAFACIL pap ranbouse w kòb ou pèdi an.
    </p>

    <p>
 <h3>5. EARN</h3>
  Avan ou kòmanse depoze USDT nan SAFACIL EARN ou dwe li FAQ an pou w ka byen enfòme w sou sèvis lan.
  Sèvis EARN nan pa otomatik ou dwe konekte chak jou pou randman yo ka ogmante sinon w ap pèdi jou an,
  men ou ka toujou ekri sèvis teknik SAFACIL lan pou ka ajoute randman an pou ou.
<br>
    </p>

    <p>
 <h3>6. KAT VISA</h3>
  SAFACIL siyen yon akò avèk yon lòt patnè komèsyal etranje ki pèmèt SAFACIL jwenn posiblite pou kreye kat VISA pou tout moun ki gen yon kont SAFACIL ki aktif, SAFACIL sèlman gen dwa pou kreye epi rechaje kat VISA yo.
  <br>
  Ou pagen dwa itilize kat sa pou resevwa lajan paske ou pap gen posiblite pou retire kòb la sa ka rive kat Visa a tou bloke si ou al eseye voye lajan sou li pa yon lòt mwayen ki pa Safacil.
  <br>
  Si sa ta rive ou ta pèdi aksè ak kat VISA ou genyen an SAFACIL pap ranbouse w kòb ou pèdi sou kat lan ni kòb ou te kreye kat lan, men w ap gen aksè pou jwenn yon lòt kat ak yon spesyal rabè.
  <br>
  Si sa ta rive ou itilize kat la sou yon platfom ki pabon epi ou pèdi kòb ki sou kat lan SAFACIL pap ranbouse w okenn kòb, tout acha, pèt ak depans ou yo se ou ki responsab yo, SAFACIL pap responsab anyen.
  <br>
  <br>
  Avan ou itilize kat lan asire w ke ou gen ase kòb sou li ki ka kouvri depans ou pral fè yo sinon kat lan ap bloke otomatikman.
  <br>
  Si ou paka kreye kat lan ekri sipò SAFACIL yo y ap ede w.
    </p>



    <p>
 <h3>7. Afilyasyon</h3>
  Otomatikman ou gen yon kont SAFACIL ou tou elijib pou vin yon patnè SAFACIL k ap pèmèt ou fè lajan chak jou.
  Anvan ou envite yon moun klike sou lyen afilye w lan ou dwe bal tout enfo ki konsène SAFACIL san ke ou pa bay move enfòmasyon.
  <br>
  Pa eseye kreye fo kont pou fè lajan epi pa asosye SAFACIL avek kontni ki gen rapò ak :
  <br>
  1 - SÈKS
  <br>
  2 - VYOLANS
  <br>
  3 - ALKÒL & DWÒG
  <br>
  4 - DISKRIMINASYON
  <br>
    </p>

    <p>
 <h3>8. SAFACIL PAY</h3>
  Se yon sèvis ke SAFACIL ofri k ap pèmèt ou voye ak resevwa lajan bay fanmi w ak zanmi w tout kote nan mond lan san ke ou pa peye frè pou transfè a.
  <br>
  Pou itilize sèvis sa ou dwe gen yon kont SAFACIL ak yon nimewo telefòn ki valid.
  Pa voye lajan bay moun ou pa konnen epi toujou verifye non moun w ap voye lajan pou li an avan menm ou valide tranzaksyon an, SAFACIL pap responsab okenn erè ou fè bò kote pa w.
  <br>
  Si ou pagen kòb sou kont SAFACIL ou, ou ka pase kay yon ajan otorize SAFACIL PAY pou ka voye ak resevwa lajan.
    </p>

    <p>
 <h3>9. MY SAFACIL</h3>
  Pou itilize Sèvis MY SAFACIL lan, nimewo ou gen sou kont SAFACIL lan dwe lye avèk yon kont WhatsApp, epi ou dwe gen yon PIN 4 chif ki anrejistre.
  Ou dwe pwoteje kont WhatsApp ou an pou anpeche yon moun monte sou li san otorizasyon w, SAFACIL pap responsab okenn erè ak neglijans ki sòti bò kote paw.
    </p>

    <p>
 <h3>10. P2P</h3>
 Sèvis P2P a ap pèmèt ou vann ak achte kripto an sekirite e ak pri ke ou vle.
 <br>
 Ou dwe li sa ki ekri nan chak seksyon P2P yo avan ke ou lanse yon tranzaksyon.
 <br>
 SAFACIL pap responsab okenn erè ki soti bò kote pa w.
 <br>

    </p>

    <p>
 <h3>11. Politik Konfidansyalite</h3>
 Safacil stoke done ou yo nan objektif pou adapte sèvis li ofri yo an fonksyon de demand ou.
 <br>
 Safacil pap ni pataje ni vann done ou yo ak pèsonn
 <br>
Si ou vle ou kapab ekri pou siprime tout done ou gen sou sistem nan.
 <br>

    </p>

    <p>
 <h3>12. FINAL</h3>
  SAFACIL pap responsab okenn (erè,neglijans,pèt,pirataj) ke ou sibi, ou dwe pwoteje telefòn ou ak kont SAFACIL ou an a 100%, pa itilize imel ak modpas ou kreye kont SAFACIL lan sou facebook ni sou okenn lòt rezo sosyal, pa kite idantifyan koneksyon kont SAFACIL ou an sou telefòn lòt moun. Tout tranzaksyon w ap fè yo dwe pase pa SAFACIL pa fè okenn acha sou rezo yo sinon w ap pèdi lajan w e SAFACIL pap responsab.
<br>
    </p>
    <br>  <br>  <br>  <br>
</section>
</body>

</html>
